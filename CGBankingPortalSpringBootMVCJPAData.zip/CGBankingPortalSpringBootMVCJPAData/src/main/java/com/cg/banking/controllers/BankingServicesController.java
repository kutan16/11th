package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/registerAccount")
	public ModelAndView registerAccount(@ModelAttribute Account account){
		account=bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage","account",account);
	}
	@RequestMapping("/accountDetails")
	public ModelAndView getAssociateDetails(@RequestParam int accountNo)throws AccountNotFoundException, BankingServicesDownException{
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("findAccountDetailsPage","account",account);
	}
	@RequestMapping("/depositAmount")
	public ModelAndView depositAmount(@RequestParam int accountNo,@RequestParam float amount) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		float deposit = bankingServices.depositAmount(accountNo,amount);
		return new ModelAndView("depositSuccess","deposit",deposit);
	}
	@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmount(@RequestParam int accountNo,@RequestParam float amount,@RequestParam int pinNumber)throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		float withdraw=bankingServices.withdrawAmount(accountNo,amount,pinNumber);
		return new ModelAndView("withdrawSuccess","withdraw",withdraw);
	}
	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransfer(@RequestParam long accountNoTo, @RequestParam long accountNoFrom, @RequestParam float transferAmount, @RequestParam int pinNumber)throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException{
		boolean fund=bankingServices.fundTransfer(accountNoTo,accountNoFrom,transferAmount,pinNumber);
		return new ModelAndView("fundSuccess","fund",fund);
	}
}
