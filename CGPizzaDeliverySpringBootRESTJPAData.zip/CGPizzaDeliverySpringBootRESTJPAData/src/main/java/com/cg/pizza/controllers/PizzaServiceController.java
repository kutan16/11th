package com.cg.pizza.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Orders;
import com.cg.pizza.exceptions.CustomerDetailsNotFoundException;
import com.cg.pizza.exceptions.OrderDetailsNotFoundException;
import com.cg.pizza.exceptions.PizzaNotFoundException;
import com.cg.pizza.services.PizzaService;

@Controller
public class PizzaServiceController {
	
	@Autowired
	private PizzaService pizzaService;
	
	@RequestMapping(value={"/acceptCustomerDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptCustomerDetails(@ModelAttribute Customer customer) throws CustomerDetailsNotFoundException{
		customer=pizzaService.acceptCustomerDetails(customer);
		return new ResponseEntity<>("Customer details successfully added for customerId"+customer.getCustomerId(),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getCustomerDetails/{customerId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Customer>getCustomerDetails(@PathVariable(value="customerId")int customerId)throws CustomerDetailsNotFoundException{
		Customer customer = pizzaService.getCustomerDetails(customerId);
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getAllCustomerDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Customer>> getAllCustomerDetails() {
		return new ResponseEntity<List<Customer>>(pizzaService.getAllCustomerDetails(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeCustomerDetails/{customerId}",method=RequestMethod.DELETE,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeCustomerDetails(@PathVariable(value="customerId") int customerId)throws CustomerDetailsNotFoundException{
		pizzaService.removeCustomerDetails(customerId);
		return new ResponseEntity<>("Customer Details Successfully removed",HttpStatus.OK);
	}
	
	
	@RequestMapping(value={"/acceptOrderDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptOrdersDetails(@ModelAttribute Orders order,@RequestParam int customerId) throws OrderDetailsNotFoundException, CustomerDetailsNotFoundException{
		Orders order1=pizzaService.acceptOrderDetails(order, customerId);
		return new ResponseEntity<>("Order details successfully added for orderId"+order1.getOrderId(),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getOrderDetails/{orderId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Orders>getOrderDetails(@PathVariable(value="customerId")int orderId)throws OrderDetailsNotFoundException{
		Orders order = pizzaService.getOrderDetails(orderId);
		return new ResponseEntity<Orders>(order,HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getAllOrderDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Orders>> getAllOrderDetails() {
		return new ResponseEntity<List<Orders>>(pizzaService.getAllOrderDetails(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeOrderDetails/{orderId}",method=RequestMethod.DELETE,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeOrderDetails(@PathVariable(value="orderId") int orderId)throws OrderDetailsNotFoundException{
		pizzaService.removeOrderDetails(orderId);
		return new ResponseEntity<>("Order Details Successfully removed",HttpStatus.OK);
	}
}
