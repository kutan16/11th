package com.cg.pizza.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Orders;
import com.cg.pizza.daoservices.CustomerDAO;
import com.cg.pizza.daoservices.OrderDAO;
import com.cg.pizza.exceptions.CustomerDetailsNotFoundException;
import com.cg.pizza.exceptions.OrderDetailsNotFoundException;

@Component("pizzaService")
public class PizzaServiceImpl implements PizzaService{

	@Autowired
	private CustomerDAO customerDao;
	@Autowired
	private OrderDAO orderDao;

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		return customerDao.save(customer);
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		return customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found for customer ID "+customerID));
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDao.findAll();
	}

	@Override
	public boolean removeCustomerDetails(int customerId) {
		customerDao.deleteById(customerId);
		return true;
	}

//	@Override
//	public Orders acceptOrderDetails(Orders order) {
//		return orderDao.save(order);
//	}
	@Override
	public Orders acceptOrderDetails(Orders order,int customerId) throws CustomerDetailsNotFoundException {
		Customer customer = getCustomerDetails(customerId);
		order.setCustomer(customer);
		return orderDao.save(order);
	}

	@Override
	public Orders getOrderDetails(int orderId) throws OrderDetailsNotFoundException {
		return orderDao.findById(orderId).orElseThrow(()->new OrderDetailsNotFoundException("Order details not found for Order ID "+orderId));
	}

	@Override
	public List<Orders> getAllOrderDetails() {
		return orderDao.findAll();
	}

	@Override
	public boolean removeOrderDetails(int orderId) {
		orderDao.deleteById(orderId);
		return true;
	}

	@Override
	public double calculateTotalPrice(int customerId, int orderId) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
