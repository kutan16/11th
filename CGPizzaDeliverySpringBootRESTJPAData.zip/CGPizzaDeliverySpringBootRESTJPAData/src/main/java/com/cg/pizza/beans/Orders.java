package com.cg.pizza.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Orders {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="order_id")
	private int orderId;
	private String orderStatus;
	private String pizzaName;
	private String pizzaType;
	private double pizzaPrice;
	@ManyToOne
	@JoinColumn(name="customer_id",nullable=false)
	private Customer customer;
	public Orders() {
		super();
	}
	public Orders(int customerId) {}
	public Orders(int orderId, String orderStatus, String pizzaName, String pizzaType, double pizzaPrice,
			Customer customer) {
		super();
		this.orderId = orderId;
		this.orderStatus = orderStatus;
		this.pizzaName = pizzaName;
		this.pizzaType = pizzaType;
		this.pizzaPrice = pizzaPrice;
		this.customer = customer;
	}
	public Orders(int orderId, String orderStatus, String pizzaName, String pizzaType, double pizzaPrice) {
		super();
		this.orderId = orderId;
		this.orderStatus = orderStatus;
		this.pizzaName = pizzaName;
		this.pizzaType = pizzaType;
		this.pizzaPrice = pizzaPrice;
	}
	public Orders(Customer customer2) {
		// TODO Auto-generated constructor stub
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public double getPizzaPrice() {
		return pizzaPrice;
	}
	public void setPizzaPrice(double pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + orderId;
		result = prime * result + ((orderStatus == null) ? 0 : orderStatus.hashCode());
		result = prime * result + ((pizzaName == null) ? 0 : pizzaName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(pizzaPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((pizzaType == null) ? 0 : pizzaType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Orders other = (Orders) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (orderId != other.orderId)
			return false;
		if (orderStatus == null) {
			if (other.orderStatus != null)
				return false;
		} else if (!orderStatus.equals(other.orderStatus))
			return false;
		if (pizzaName == null) {
			if (other.pizzaName != null)
				return false;
		} else if (!pizzaName.equals(other.pizzaName))
			return false;
		if (Double.doubleToLongBits(pizzaPrice) != Double.doubleToLongBits(other.pizzaPrice))
			return false;
		if (pizzaType == null) {
			if (other.pizzaType != null)
				return false;
		} else if (!pizzaType.equals(other.pizzaType))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", orderStatus=" + orderStatus + ", pizzaName=" + pizzaName
				+ ", pizzaType=" + pizzaType + ", pizzaPrice=" + pizzaPrice + ", customer=" + customer + "]";
	}
	
	
}
