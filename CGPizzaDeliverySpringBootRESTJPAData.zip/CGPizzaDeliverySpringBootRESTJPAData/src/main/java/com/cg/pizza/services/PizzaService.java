package com.cg.pizza.services;

import java.util.List;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.beans.Orders;
import com.cg.pizza.exceptions.CustomerDetailsNotFoundException;
import com.cg.pizza.exceptions.OrderDetailsNotFoundException;

public interface PizzaService {
	Customer acceptCustomerDetails(Customer customer);
	Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException;
	List<Customer>getAllCustomerDetails();
	boolean removeCustomerDetails(int customerId);
//	Orders acceptOrderDetails(Orders order);
//	Orders acceptOrderDetails(int customerId) throws CustomerDetailsNotFoundException;
	Orders getOrderDetails(int orderId) throws OrderDetailsNotFoundException;
	List<Orders>getAllOrderDetails();
	boolean removeOrderDetails(int orderId);
	double calculateTotalPrice(int customerId,int orderId);
	Orders acceptOrderDetails(Orders order, int customerId) throws CustomerDetailsNotFoundException;
}
