package com.cg.pizza.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.pizza.beans.Orders;

public interface OrderDAO extends JpaRepository<Orders, Integer>{

}
