package com.cg.movie.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.daoservices.SongDAO;
import com.cg.movie.exceptions.MovieDetailNotFoundException;
@Component("movieServices")
public class MovieServicesImpl implements MovieServices{
	@Autowired
	private MovieDAO movieDao;
	@Autowired
	private SongDAO songDao;
	
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		Movie movie1= movieDao.save(movie);
		songDao.save(new Song(movie1));
		return movie1;
	}

	@Override
	public Movie getMovieDetails(int movieId) throws MovieDetailNotFoundException {
		return movieDao.findById(movieId).orElseThrow(()->new MovieDetailNotFoundException());
	}

	@Override
	public List<Movie> getAllMovieDetails() {
		return movieDao.findAll();
	}

	@Override
	public List<Song> getAllSongDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeMovieDetails(int movieId) throws MovieDetailNotFoundException {
		movieDao.deleteById(movieId);
		return true;
	}
	
}
