package com.cg.movie.services;

import java.util.List;
import java.util.Map;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.exceptions.MovieDetailNotFoundException;

public interface MovieServices {
	Movie acceptMovieDetails(Movie movie);
	Movie getMovieDetails(int movieId)throws MovieDetailNotFoundException;
	List<Movie>getAllMovieDetails()throws MovieDetailNotFoundException;
	List<Song>getAllSongDetails();
	boolean removeMovieDetails(int movieId)throws MovieDetailNotFoundException;
}
