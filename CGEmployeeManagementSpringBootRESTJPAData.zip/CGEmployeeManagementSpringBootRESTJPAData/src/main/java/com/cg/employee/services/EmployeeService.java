package com.cg.employee.services;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;

public interface EmployeeService {
	Employee acceptEmployeeDetails(Employee employee);
	Employee getEmployeeDetails(int empId)throws EmployeeDetailsNotFoundException;
	List<Employee>getAllEmployeeDetails();
	boolean removeEmployeeDetails(int empId)throws EmployeeDetailsNotFoundException;
	Employee updateEmployeeDetails(Employee employee);
}
