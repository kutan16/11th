package com.cg.employee.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	private String city;
	private String State;
	private int pinCode;
	public Address() {
		super();
	}
	public Address(String city, String state, int pinCode) {
		super();
		this.city = city;
		State = state;
		this.pinCode = pinCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((State == null) ? 0 : State.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + pinCode;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (State == null) {
			if (other.State != null)
				return false;
		} else if (!State.equals(other.State))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (pinCode != other.pinCode)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", State=" + State + ", pinCode=" + pinCode + "]";
	}
	
}