package com.cg.employee.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
import com.cg.employee.services.EmployeeService;

@Controller
public class EmployeeServiceController {
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value="/acceptEmployeeDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>acceptEmployeeDetails(@ModelAttribute Employee employee)throws EmployeeDetailsNotFoundException{
		employee=employeeService.acceptEmployeeDetails(employee);
		return new ResponseEntity<>("Employee details added successfully for Employee ID"+employee.getEmpId(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/getEmployeeDetails/{empId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Employee> getEmployeeDetails(@PathVariable(value="empId") int empId)throws EmployeeDetailsNotFoundException{
		Employee employee=employeeService.getEmployeeDetails(empId);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getAllEmployeeDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Employee>> getAllEmployeeDetailsPathParam() {
		return new ResponseEntity<List<Employee>>(employeeService.getAllEmployeeDetails(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeEmployeeDetails/{empId}",method=RequestMethod.DELETE,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeEmployeeDetails(@PathVariable(value="empId") int empId)throws EmployeeDetailsNotFoundException{
		employeeService.removeEmployeeDetails(empId);
		return new ResponseEntity<>("Employee Details Successfully removed",HttpStatus.OK);
	}
	
	@RequestMapping(value="/updateEmployeeDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>updateEmployeeDetails(@ModelAttribute Employee employee)throws EmployeeDetailsNotFoundException{
		employee=employeeService.updateEmployeeDetails(employee);
		return new ResponseEntity<>("Employee details UPDATED successfully for Employee ID"+employee.getEmpId(),HttpStatus.OK);
	}
}
