package com.cg.employee.exceptions;

public class EmployeeDetailsNotFoundException extends Exception{

	public EmployeeDetailsNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
