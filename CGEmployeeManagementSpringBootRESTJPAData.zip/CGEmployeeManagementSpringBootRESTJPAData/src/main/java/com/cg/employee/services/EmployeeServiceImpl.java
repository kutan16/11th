package com.cg.employee.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.beans.Employee;
import com.cg.employee.dao.EmployeeDAO;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
@Component("employeeService")
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeDAO empdao;
	
	Employee employee = new Employee();

	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		return empdao.save(employee);	
	}
	
	@Override
	public Employee getEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {
		return empdao.findById(empId).orElseThrow(()->new EmployeeDetailsNotFoundException("Employee Details not found for Employee ID "+empId));
	}

	@Override
	public List<Employee> getAllEmployeeDetails() {
		return empdao.findAll();
	}

	@Override
	public boolean removeEmployeeDetails(int empId) throws EmployeeDetailsNotFoundException {
		empdao.deleteById(empId);
		return true;
	}

	@Override
	public Employee updateEmployeeDetails(Employee employee) {
		return empdao.save(employee);
	}

}
