package com.cg.movie.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.movie.beans.Movie;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.exceptions.MovieNotFoundException;

@Component("movieServices")
public class MovieServicesImpl implements MovieServices {
	
	@Autowired
	private MovieDAO movieDao;

	@Override
	public Movie acceptMovieDetails(Movie movie) {
		movie=movieDao.save(movie);
		return movie;
	}

	@Override
	public Movie getMovieDetails(int movieCode) throws MovieNotFoundException {
		return movieDao.findById(movieCode).orElseThrow(()->new MovieNotFoundException("Movie Details Not found for MovieCode :"+movieCode));
	}

	@Override
	public List<Movie> getAllMovieDetails() {
		return movieDao.findAll();
	}

	@Override
	public boolean removeMovieDetails(int movieCode) throws MovieNotFoundException {
		movieDao.delete(getMovieDetails(movieCode));
		return true;
	}
}
