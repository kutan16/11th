package com.cg.movie.services;

import java.util.List;
import com.cg.movie.beans.Movie;
import com.cg.movie.exceptions.MovieNotFoundException;

public interface MovieServices {
	Movie acceptMovieDetails(Movie movie);
	Movie getMovieDetails(int movieCode) throws MovieNotFoundException;
	List<Movie> getAllMovieDetails();
	boolean removeMovieDetails(int movieCode) throws MovieNotFoundException;
}
