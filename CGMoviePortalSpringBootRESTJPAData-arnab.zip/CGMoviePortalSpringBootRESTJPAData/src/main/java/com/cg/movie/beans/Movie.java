package com.cg.movie.beans;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Movie {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int movieCode;
	private String movieName;
	private String releaseDate;
	private String producer;
	private int movieBudget;
	
	@Embedded
	private Song song;

	public Movie() {
		super();
	}

	public Movie(int movieCode, String movieName, String releaseDate, String producer, int movieBudget, Song song) {
		super();
		this.movieCode = movieCode;
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.producer = producer;
		this.movieBudget = movieBudget;
		this.song = song;
	}

	public int getMovieCode() {
		return movieCode;
	}

	public void setMovieCode(int movieCode) {
		this.movieCode = movieCode;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getProducer() {
		return producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public int getMovieBudget() {
		return movieBudget;
	}

	public void setMovieBudget(int movieBudget) {
		this.movieBudget = movieBudget;
	}

	public Song getSong() {
		return song;
	}

	public void setSong(Song song) {
		this.song = song;
	}

	@Override
	public String toString() {
		return "Movie [movieCode=" + movieCode + ", movieName=" + movieName + ", releaseDate=" + releaseDate
				+ ", producer=" + producer + ", movieBudget=" + movieBudget + ", song=" + song + "]";
	}
}
