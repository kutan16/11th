package com.cg.movie.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Song {
	private int songId;
	private String songName;
	private String songSinger;

	public Song() {
		super();
	}

	public Song(int songId, String songName, String songSinger) {
		super();
		this.songId = songId;
		this.songName = songName;
		this.songSinger = songSinger;
	}

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSongSinger() {
		return songSinger;
	}

	public void setSongSinger(String songSinger) {
		this.songSinger = songSinger;
	}

	@Override
	public String toString() {
		return "Song [songId=" + songId + ", songName=" + songName + ", songSinger=" + songSinger + "]";
	}
}
